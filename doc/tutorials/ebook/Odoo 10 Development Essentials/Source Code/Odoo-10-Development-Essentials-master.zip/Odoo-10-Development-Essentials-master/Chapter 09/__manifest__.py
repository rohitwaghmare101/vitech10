{
    'name': 'To-Do Kanban board',
    'description': 'Kanban board to manage to-do tasks.',
    'author': 'Daniel Reis',
    'depends': ['todo_ui'],
    'data': ['views/todo_view.xml'],
}
