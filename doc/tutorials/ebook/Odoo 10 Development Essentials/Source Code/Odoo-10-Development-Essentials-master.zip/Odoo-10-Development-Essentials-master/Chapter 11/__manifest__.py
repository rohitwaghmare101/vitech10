{
    'name': 'To-Do Website',
    'description': 'Manage your personal To-Do tasks.',
    'author': 'Daniel Reis',
    'depends': ['todo_kanban', 'website_form'],
    'data': [
        'views/todo_web.xml',
        'views/todo_extend.xml',
        'data/config_data.xml',
    ],
}
