{
    'name': 'User interface improvements to the To-Do app',
    'description': 'User friendly features.',
    'author': 'Daniel Reis',
    'depends': ['todo_user'],
    'data': [
        'security/ir.model.access.csv',
        'views/todo_view.xml',
        'views/todo_menu.xml',
    ],
}
